from setuptools import setup

setup(name='stern',
      version='1.0',
      description='Python module by developer saivan',
      packages=['stern'],
      author_email='vasilsalkou@gmail.com',
      zip_safe=False)